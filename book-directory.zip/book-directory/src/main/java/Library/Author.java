package Library;

import org.bson.Document;

public class Author {

	private String name;

    public Author(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

	public static Author toAuthor(Document authorData) {
		String auth = authorData.getString("author");
		return new Author(auth);
		
	}


}

