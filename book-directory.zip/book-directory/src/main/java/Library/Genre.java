package Library;

import org.bson.Document;

public class Genre {
	
	private String name;

    public Genre(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

	public static Genre toGenre(Document genreData) {
		String genre = genreData.getString("genre");
		return new Genre(genre);
	}

}
