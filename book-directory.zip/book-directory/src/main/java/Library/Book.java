package Library;

import org.bson.Document;

import DatabaseAccessObject.authorDAO;
import DatabaseAccessObject.genreDAO;

public class Book {
	
	private Author author;
    private Genre genre;
	private String title;
	private String description;
	private String id;

	public Book() {
		// TODO Auto-generated constructor stub
	}
    public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
    
    public Book(String title, Author author, Genre genre, String description) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.description= description;
    }
    public Book(String title, Author author, Genre genre, String description, String id) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.description= description;
        this.id = id;
    }
    
    public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle()
    {
    	return title;
    }

	public Author getAuthor() {
        return author;
    }

    public Genre getGenre() {
        return genre;
    }
    public String toString() {
        return title + " by " + author.getName() + " (" + genre.getName() + ")";
    }
    
    public static Book toBook(Document bookData)
    {
    	String title = bookData.getString("title");
    	String id = bookData.getObjectId("_id").toString();
    	String description = bookData.getString("description");
	    // Retrieve author information
	    String authorID = bookData.getString("author");
	    String authorName = authorDAO.findAuthorName(authorID);
	    Author author = new Author(authorName);

	    // Retrieve genre information
	    String genreID = bookData.getString("genre");
	    String genreName = genreDAO.findGenreName(genreID);  
	    Genre genre = new Genre(genreName);

	    return new Book(title, author, genre, description, id);
    	
		
    }
	

}
