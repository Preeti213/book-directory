package DatabaseAccessObject;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Connection {
static MongoCollection col;
	
	public static MongoCollection createConnection(String table)
	{
		MongoClient client = MongoClients.create("mongodb+srv://preeti213:preeti213"
				+ "@cluster0.i1lba8w.mongodb.net/?retryWrites=true&w=majority");
		
		MongoDatabase db = client.getDatabase("books_directory");
		col = db.getCollection(table);	
		
		return col;
	}

}
