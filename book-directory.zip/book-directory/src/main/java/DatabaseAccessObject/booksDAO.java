package DatabaseAccessObject;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.DeleteResult;

import Library.Author;
import Library.Book;

public class booksDAO {

	static MongoCollection col;
	
	public static List<Book> getBooks()
	{
		col = Connection.createConnection("books");
		
		List<Book> booksList = new ArrayList();
		
		FindIterable<Document> cursor = col.find();
		for (Document bookData : cursor) {
		    booksList.add(Book.toBook(bookData));
		}
		
		return booksList;
			
	}
	
	public static void addBooks(String title, String author, String genre, String description)
	{
		col = Connection.createConnection("books");
		
		//create author
		String authorID = authorDAO.findAuthorID(author);
		
		//create genre
		String genreID = genreDAO.findGenreID(genre);
		
		//add book
		Document doc = new Document("title" , title).append("author", authorID)
				.append("genre", genreID).append("description", description);
		col.insertOne(doc);
		
	}

	public static List<Book> getBooks(String filterType, String filterName) {
		
		col = Connection.createConnection("books");
		
		List<Book> booksList = new ArrayList();
		
		FindIterable<Document> result = col.find(Filters.eq(filterType, filterName));
		
		for (Document bookData : result) {
		    booksList.add(Book.toBook(bookData));
		}
		
		return booksList;
	}

	public static Book getDetails(String title) {
		col = Connection.createConnection("books");
	    
	    Document query = new Document("title", title);
	    FindIterable<Document> result = col.find(query);

	    // Retrieve the first document if available
	    Document firstDocument = result.first();
	    if (firstDocument != null)
	    	return Book.toBook(firstDocument);
		
		return null;
		
	}

	public static boolean deleteBook(String id) {
	
		ObjectId objectId = new ObjectId(id);
        Document query = new Document("_id", objectId);
        DeleteResult result = col.deleteOne(query);

        // Check if a document was deleted (i.e., affected count is greater than 0)
        return result.getDeletedCount() > 0;
	
	}
	public static Book getBookByID(String id) {
	    
	try {
	        ObjectId objectId = new ObjectId(id); 

	        Document query = new Document("_id", objectId);
	        FindIterable<Document> result = col.find(query);

	        Document firstDocument = result.first();
	        if (firstDocument != null)
	        {
	        	 return Book.toBook(firstDocument);
	        }

	    } catch (IllegalArgumentException e) {
	        System.out.println("error in bookDAO getBookById");
	    }

	    return null;
	}

	public static long getCount(String type, String name) {
		
		col = Connection.createConnection("books");
	    
		 Document query = new Document(type, name);
        
        long count = col.countDocuments(query);
        return count;
	}

	public static void updateBook(String id, String title, String author, String genre, String description) {
		
		ObjectId objectId = new ObjectId(id);
        Document query = new Document("_id", objectId);
        
        String authorID = authorDAO.findAuthorID(author);
		
		String genreID = genreDAO.findGenreID(genre);
		
         Document update = new Document("$set", new Document("title" , title).append("author", authorID)
 				.append("genre", genreID).append("description", description));

         
         col.updateOne(query, update);
	}


}
