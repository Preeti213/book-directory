package Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DatabaseAccessObject.*;
import Library.*;

/**
 * Servlet implementation class deleteBook
 */
public class deleteBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("id");

		//get book details
		Book b = booksDAO.getBookByID(id);
		
		//check author count & delete if required
		String authorID=authorDAO.findAuthorID(b.getAuthor().getName());
		long authorCount = booksDAO.getCount("author",authorID );
		if(authorCount ==1)//delete author
		{
			authorDAO.deleteAuthor(authorID);
		}
		
		//delete genre if == 1
		String genreID =  genreDAO.findGenreID(b.getGenre().getName());
		long genreCount = booksDAO.getCount("genre",genreID);
		
		if(genreCount ==1)
		{
			genreDAO.deleteGenre(genreID);
		}
		
		//deleteBook
		booksDAO.deleteBook(id);
		
		RequestDispatcher rd = request.getRequestDispatcher("bookDirectoryMain");
		rd.forward(request, response);
		
		
	}
	
	

}
