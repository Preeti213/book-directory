package Servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DatabaseAccessObject.*;
import Library.*;


public class bookDirectoryMain extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		  List<Book> booksList = booksDAO.getBooks();
		  
		  //get authors
		  List<Author> authors = authorDAO.getAuthor();
		  
		  //get genres
		  List<Genre> genres = genreDAO.getGenre();
		  
		  HttpSession session = request.getSession();
		 
		  session.setAttribute("authors", authors);
		  session.setAttribute("genres", genres);
		  session.setAttribute("booksList", booksList);
		  request.getRequestDispatcher("index.jsp").forward(request, response);
		  
	}

}
