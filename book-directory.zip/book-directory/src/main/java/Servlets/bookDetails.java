package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DatabaseAccessObject.booksDAO;
import Library.Book;
import javax.servlet.RequestDispatcher;

/**
 * Servlet implementation class bookDetails
 */
public class bookDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String title = request.getParameter("title");
		Book b = booksDAO.getDetails(title);
		
		request.setAttribute("id", b.getId());
		request.setAttribute("title", b.getTitle());
		request.setAttribute("author", b.getAuthor().getName());
		request.setAttribute("genre", b.getGenre().getName());
		request.setAttribute("description", b.getDescription());
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("bookDetails.jsp");
		dispatcher.forward(request, response);
		  
		
		
	}

}
