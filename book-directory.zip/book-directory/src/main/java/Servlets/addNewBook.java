package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DatabaseAccessObject.booksDAO;

/**
 * Servlet implementation class addNewBook
 */
public class addNewBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String genre = request.getParameter("genre");
		String description = request.getParameter("description");
		booksDAO.addBooks(title, author, genre, description);
		response.sendRedirect("bookDirectoryMain");
		
	}
}
