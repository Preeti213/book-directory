package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.Document;
import org.bson.types.ObjectId;

import DatabaseAccessObject.authorDAO;
import DatabaseAccessObject.booksDAO;
import DatabaseAccessObject.genreDAO;
import Library.Book;

/**
 * Servlet implementation class updateBook
 */
public class updateBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("id");
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String genre = request.getParameter("genre");
		String description = request.getParameter("description");
		
		//BooksDAO -update book
		Book b = booksDAO.getBookByID(id);
		
		//check author
		if(!b.getAuthor().getName().equals(author))
		{
			System.out.println("author chng");
			String authorID=authorDAO.findAuthorID(b.getAuthor().getName());
			long authorCount = booksDAO.getCount("author",authorID );
			if(authorCount ==1)//delete author
			{
				if(authorDAO.deleteAuthor(authorID))
					System.out.println("delted");
				else
					System.out.println("error");
			}
		}
		
		//check genre value == 1 delete old genre
		if(!b.getGenre().getName().equals(genre))
		{
			System.out.println("genre chng");
			String genreID =  genreDAO.findGenreID(b.getGenre().getName());
			long genreCount = booksDAO.getCount("genre",genreID);
			
			if(genreCount ==1)
			{
				if(genreDAO.deleteGenre(genreID))
					System.out.println("delted");
				else
					System.out.println("error");
			}
			
		}
		//update book
		booksDAO.updateBook(id, title, author, genre, description);
		
	}

}
